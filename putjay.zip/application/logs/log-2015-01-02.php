<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-02 16:28:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'ODBC'@'localhost' (using password: NO) C:\xampp\htdocs\pricity\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-01-02 16:28:30 --> Unable to connect to the database
ERROR - 2015-01-02 16:50:34 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\pricity\application\views\header.php 15
ERROR - 2015-01-02 16:50:34 --> Severity: Notice  --> Undefined variable: js C:\xampp\htdocs\pricity\application\views\header.php 22
ERROR - 2015-01-02 16:50:34 --> Severity: Notice  --> Undefined variable: css C:\xampp\htdocs\pricity\application\views\header.php 22
ERROR - 2015-01-02 16:51:51 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\pricity\application\views\header.php 15
ERROR - 2015-01-02 16:51:51 --> Severity: Notice  --> Undefined variable: js C:\xampp\htdocs\pricity\application\views\header.php 22
ERROR - 2015-01-02 16:51:51 --> Severity: Notice  --> Undefined variable: css C:\xampp\htdocs\pricity\application\views\header.php 22
ERROR - 2015-01-02 16:52:12 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\pricity\application\views\header.php 15
ERROR - 2015-01-02 16:52:12 --> Severity: Notice  --> Undefined variable: js C:\xampp\htdocs\pricity\application\views\header.php 22
ERROR - 2015-01-02 16:52:12 --> Severity: Notice  --> Undefined variable: css C:\xampp\htdocs\pricity\application\views\header.php 22
ERROR - 2015-01-02 16:52:30 --> Severity: Notice  --> Undefined variable: js C:\xampp\htdocs\pricity\application\views\header.php 22
ERROR - 2015-01-02 16:52:30 --> Severity: Notice  --> Undefined variable: css C:\xampp\htdocs\pricity\application\views\header.php 22
