<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-04 13:37:55 --> Severity: Notice  --> Undefined variable: content_header C:\xampp\htdocs\twingernew\application\views\header.php 28
ERROR - 2015-01-04 13:42:40 --> Severity: Notice  --> Undefined variable: content_header C:\xampp\htdocs\twingernew\application\views\header.php 27
