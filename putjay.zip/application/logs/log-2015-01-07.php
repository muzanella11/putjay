<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-07 17:41:03 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-07 17:56:33 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-07 22:54:46 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-07 23:51:55 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-07 23:53:16 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
