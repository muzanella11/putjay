<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-08 10:19:33 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 10:19:46 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 10:22:32 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 10:23:56 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 10:24:15 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 10:24:44 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 10:24:51 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 10:27:04 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 10:28:55 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 10:30:48 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 12:29:26 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-01-08 12:34:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 12:36:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 12:37:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 12:39:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 12:45:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 12:46:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 12:48:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 12:52:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 12:57:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 13:05:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 13:05:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 13:06:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '@b.c' at line 1
ERROR - 2015-01-08 17:30:19 --> Severity: Notice  --> Undefined variable: database C:\xampp\htdocs\twingernew\application\controllers\ajax.php 68
ERROR - 2015-01-08 17:30:22 --> Severity: Notice  --> Undefined variable: database C:\xampp\htdocs\twingernew\application\controllers\ajax.php 68
ERROR - 2015-01-08 17:31:09 --> Severity: Notice  --> Undefined variable: database C:\xampp\htdocs\twingernew\application\controllers\ajax.php 68
ERROR - 2015-01-08 17:31:14 --> Severity: Notice  --> Undefined variable: database C:\xampp\htdocs\twingernew\application\controllers\ajax.php 68
ERROR - 2015-01-08 17:32:04 --> Severity: Notice  --> Undefined variable: database C:\xampp\htdocs\twingernew\application\controllers\ajax.php 68
ERROR - 2015-01-08 17:34:48 --> Severity: Notice  --> Undefined variable: database C:\xampp\htdocs\twingernew\application\controllers\ajax.php 68
ERROR - 2015-01-08 17:38:02 --> Severity: Notice  --> Undefined variable: database C:\xampp\htdocs\twingernew\application\controllers\ajax.php 68
ERROR - 2015-01-08 18:15:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''email','password','date_join')
                            VALUES('bismillah@a' at line 1
ERROR - 2015-01-08 18:19:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''email','password','date_join')
                            VALUES('bismillah@a' at line 1
ERROR - 2015-01-08 18:20:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''email','password')
                            VALUES('bismillah@a.b','sayang1' at line 1
ERROR - 2015-01-08 18:54:38 --> Severity: Notice  --> Undefined variable: content_header C:\xampp\htdocs\twingernew\application\views\header.php 30
ERROR - 2015-01-08 19:47:15 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-08 20:50:39 --> Severity: Notice  --> Undefined variable: data_user C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 20:50:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:11:09 --> Severity: Notice  --> Undefined property: Data_account::$user_model C:\xampp\htdocs\twingernew\application\controllers\data_account.php 24
ERROR - 2015-01-08 21:13:30 --> 404 Page Not Found --> home/sign_in
ERROR - 2015-01-08 21:13:41 --> 404 Page Not Found --> home/sign_in
ERROR - 2015-01-08 21:14:10 --> 404 Page Not Found --> home/sign_in
ERROR - 2015-01-08 21:29:15 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-08 21:31:54 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-08 21:32:09 --> Severity: Notice  --> Undefined variable: data_user C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:32:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:32:44 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-08 21:33:07 --> Severity: Notice  --> Undefined variable: data_user C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:33:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:33:09 --> Severity: Notice  --> Undefined variable: data_user C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:33:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:33:11 --> Severity: Notice  --> Undefined variable: data_user C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:33:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:33:12 --> Severity: Notice  --> Undefined variable: data_user C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:33:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:34:38 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:34:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:35:05 --> Severity: Notice  --> Undefined property: stdClass::$frist_name C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:36:51 --> Severity: Notice  --> Undefined property: stdClass::$frist_name C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:38:26 --> Severity: Notice  --> Undefined property: stdClass::$fristname C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 30
ERROR - 2015-01-08 21:47:56 --> Severity: Notice  --> Undefined variable: email C:\xampp\htdocs\twingernew\application\controllers\logout.php 21
ERROR - 2015-01-08 21:47:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-01-08 21:47:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
