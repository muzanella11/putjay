<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-09 09:34:40 --> Severity: Notice  --> Undefined offset:  1 C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 74
ERROR - 2015-01-09 09:34:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 74
ERROR - 2015-01-09 09:35:13 --> Severity: Notice  --> Undefined offset:  3 C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 74
ERROR - 2015-01-09 09:35:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 74
ERROR - 2015-01-09 09:35:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 74
