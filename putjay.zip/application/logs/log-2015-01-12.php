<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-12 00:45:12 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 144
ERROR - 2015-01-12 00:45:12 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 144
ERROR - 2015-01-12 00:45:15 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 144
ERROR - 2015-01-12 00:45:15 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 144
ERROR - 2015-01-12 00:45:44 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 144
ERROR - 2015-01-12 00:45:44 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 144
ERROR - 2015-01-12 01:06:30 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:06:30 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:06:31 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:06:31 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:02 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:02 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:04 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:04 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:06 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:06 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:09 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:09 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:10 --> Severity: Notice  --> Undefined variable: spch_patt C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:10:10 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Empty regular expression C:\xampp\htdocs\twingernew\application\controllers\ajax.php 169
ERROR - 2015-01-12 01:30:25 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 122
ERROR - 2015-01-12 01:30:33 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 122
ERROR - 2015-01-12 01:31:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 192
ERROR - 2015-01-12 01:39:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 192
ERROR - 2015-01-12 01:41:06 --> Severity: Notice  --> Undefined variable: data_username C:\xampp\htdocs\twingernew\application\controllers\ajax.php 192
ERROR - 2015-01-12 01:41:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 192
ERROR - 2015-01-12 01:45:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 193
ERROR - 2015-01-12 01:47:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 193
ERROR - 2015-01-12 01:47:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 193
ERROR - 2015-01-12 01:47:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 193
ERROR - 2015-01-12 01:48:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 193
ERROR - 2015-01-12 01:52:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 194
ERROR - 2015-01-12 01:52:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 194
ERROR - 2015-01-12 12:35:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 197
ERROR - 2015-01-12 12:36:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 197
ERROR - 2015-01-12 12:36:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 197
ERROR - 2015-01-12 12:38:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 202
ERROR - 2015-01-12 12:40:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 202
ERROR - 2015-01-12 16:22:04 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\views\templates\wizard\set_profile.php 89
ERROR - 2015-01-12 16:22:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\set_profile.php 89
ERROR - 2015-01-12 16:32:56 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\twingernew\application\views\templates\wizard\set_profile.php 77
ERROR - 2015-01-12 16:33:18 --> Severity: Notice  --> Use of undefined constant Y - assumed 'Y' C:\xampp\htdocs\twingernew\application\views\templates\wizard\set_profile.php 77
ERROR - 2015-01-12 16:33:18 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\twingernew\application\views\templates\wizard\set_profile.php 77
ERROR - 2015-01-12 16:33:28 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\twingernew\application\views\templates\wizard\set_profile.php 77
ERROR - 2015-01-12 16:33:59 --> Severity: Notice  --> A non well formed numeric value encountered C:\xampp\htdocs\twingernew\application\views\templates\wizard\set_profile.php 77
ERROR - 2015-01-12 16:57:01 --> 404 Page Not Found --> stylesheet
ERROR - 2015-01-12 16:57:38 --> 404 Page Not Found --> stylesheet
ERROR - 2015-01-12 16:57:39 --> 404 Page Not Found --> stylesheet
ERROR - 2015-01-12 16:57:47 --> 404 Page Not Found --> stylesheet
ERROR - 2015-01-12 17:13:21 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-12 17:13:45 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-12 17:17:17 --> Severity: Notice  --> Undefined property: Templates::$image_default C:\xampp\htdocs\twingernew\application\controllers\set_profile.php 30
