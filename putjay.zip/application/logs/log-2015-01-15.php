<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-15 08:51:52 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-01-15 18:51:03 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
