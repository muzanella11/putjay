<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-16 18:13:25 --> 404 Page Not Found --> index.php
ERROR - 2015-01-16 18:13:28 --> 404 Page Not Found --> index.php
ERROR - 2015-01-16 18:13:58 --> Severity: Warning  --> parse_url(/%27http://localhost/twingernew/stylesheet/image/default_avatar/default.jpg%27) [<a href='function.parse-url'>function.parse-url</a>]: Unable to parse URL C:\xampp\htdocs\twingernew\system\core\URI.php 219
ERROR - 2015-01-16 18:13:58 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\core\Common.php 442
ERROR - 2015-01-16 18:14:00 --> Severity: Warning  --> parse_url(/%27http://localhost/twingernew/stylesheet/image/default_avatar/default.jpg%27) [<a href='function.parse-url'>function.parse-url</a>]: Unable to parse URL C:\xampp\htdocs\twingernew\system\core\URI.php 219
ERROR - 2015-01-16 18:14:00 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\core\Common.php 442
