<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 18
ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 18
ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 18
ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 18
ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 20
ERROR - 2015-01-22 16:54:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 20
ERROR - 2015-01-22 16:57:27 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 16:57:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 16:57:27 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 16:57:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 17:02:45 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 313
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 13
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 18
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 18
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 18
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 18
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 20
ERROR - 2015-01-22 17:03:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\edit_profile_wizard.php 20
