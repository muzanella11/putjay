<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-01 16:29:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 295
ERROR - 2015-02-01 16:29:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 296
ERROR - 2015-02-01 16:29:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 297
ERROR - 2015-02-01 16:29:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 298
ERROR - 2015-02-01 16:29:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 299
ERROR - 2015-02-01 16:29:20 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-01 16:50:43 --> Severity: Notice  --> Undefined variable: email C:\xampp\htdocs\twingernew\application\controllers\ajax.php 45
ERROR - 2015-02-01 18:00:08 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 51
ERROR - 2015-02-01 18:00:10 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 51
ERROR - 2015-02-01 18:00:20 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 51
ERROR - 2015-02-01 18:00:22 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 51
ERROR - 2015-02-01 18:00:42 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 51
ERROR - 2015-02-01 18:00:43 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 51
ERROR - 2015-02-01 18:00:44 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 51
ERROR - 2015-02-01 18:00:44 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 51
ERROR - 2015-02-01 18:00:47 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 51
ERROR - 2015-02-01 18:02:27 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 78
ERROR - 2015-02-01 18:02:27 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 94
ERROR - 2015-02-01 18:37:09 --> Severity: Notice  --> Undefined variable: variable C:\xampp\htdocs\twingernew\application\controllers\ajax.php 53
ERROR - 2015-02-01 18:43:42 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 79
ERROR - 2015-02-01 18:43:42 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 95
ERROR - 2015-02-01 19:12:54 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 97
ERROR - 2015-02-01 19:12:54 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 113
ERROR - 2015-02-01 19:13:40 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 97
ERROR - 2015-02-01 19:13:40 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 113
ERROR - 2015-02-01 19:17:11 --> 404 Page Not Found --> login
ERROR - 2015-02-01 19:18:42 --> 404 Page Not Found --> login
ERROR - 2015-02-01 19:18:44 --> 404 Page Not Found --> login
ERROR - 2015-02-01 19:21:35 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\application\controllers\ajax.php:109) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-01 19:21:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\application\controllers\ajax.php:109) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-01 19:25:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\application\controllers\ajax.php:109) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-01 21:28:25 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\application\controllers\ajax.php:109) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-01 21:29:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\application\controllers\ajax.php:109) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-01 21:35:10 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\application\controllers\ajax.php:109) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-01 21:36:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\application\controllers\ajax.php:109) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-01 21:37:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\application\controllers\ajax.php:109) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-01 21:49:12 --> Severity: Notice  --> Undefined variable: data_username C:\xampp\htdocs\twingernew\application\controllers\ajax.php 283
ERROR - 2015-02-01 21:49:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-01 21:57:54 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 35
ERROR - 2015-02-01 21:57:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\wizard\data_account_body.php 35
ERROR - 2015-02-01 22:10:48 --> 404 Page Not Found --> step_two
ERROR - 2015-02-01 22:30:47 --> Severity: Notice  --> Undefined variable: data_username C:\xampp\htdocs\twingernew\application\controllers\ajax.php 285
ERROR - 2015-02-01 22:30:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-01 22:33:05 --> Severity: Notice  --> Undefined variable: data_username C:\xampp\htdocs\twingernew\application\controllers\ajax.php 287
ERROR - 2015-02-01 22:33:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-01 22:33:18 --> Severity: Notice  --> Undefined variable: data_username C:\xampp\htdocs\twingernew\application\controllers\ajax.php 287
ERROR - 2015-02-01 22:33:18 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-01 22:46:08 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 370
ERROR - 2015-02-01 22:53:54 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 320
ERROR - 2015-02-01 22:55:51 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 320
