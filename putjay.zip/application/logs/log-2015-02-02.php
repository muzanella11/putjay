<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-02 00:42:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '7''' at line 1
ERROR - 2015-02-02 00:47:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '7''' at line 1
ERROR - 2015-02-02 00:47:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '7''' at line 1
ERROR - 2015-02-02 01:18:39 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 439
ERROR - 2015-02-02 01:19:20 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 439
ERROR - 2015-02-02 01:22:05 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 439
ERROR - 2015-02-02 01:36:34 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 439
ERROR - 2015-02-02 01:39:01 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 439
ERROR - 2015-02-02 01:39:13 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 439
ERROR - 2015-02-02 01:39:25 --> Severity: Notice  --> Undefined property: Ajax::$user_model C:\xampp\htdocs\twingernew\application\controllers\ajax.php 439
ERROR - 2015-02-02 17:42:27 --> 404 Page Not Found --> profile
ERROR - 2015-02-02 17:54:44 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-02-02 18:02:17 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-02 18:02:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-02 18:02:17 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 28
ERROR - 2015-02-02 18:02:17 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 34
ERROR - 2015-02-02 18:02:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 34
ERROR - 2015-02-02 18:02:17 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 37
ERROR - 2015-02-02 18:03:44 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 29
ERROR - 2015-02-02 18:29:00 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
