<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-03 19:44:37 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-02-03 19:45:04 --> Severity: Notice  --> Undefined variable: data_user_name C:\xampp\htdocs\twingernew\application\controllers\ajax.php 289
ERROR - 2015-02-03 19:45:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 289
ERROR - 2015-02-03 19:45:07 --> Severity: Notice  --> Undefined variable: data_user_name C:\xampp\htdocs\twingernew\application\controllers\ajax.php 289
ERROR - 2015-02-03 19:45:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 289
ERROR - 2015-02-03 19:45:12 --> Severity: Notice  --> Undefined variable: data_user_name C:\xampp\htdocs\twingernew\application\controllers\ajax.php 289
ERROR - 2015-02-03 19:45:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 289
ERROR - 2015-02-03 19:47:26 --> Severity: Notice  --> Undefined variable: data_user_name C:\xampp\htdocs\twingernew\application\controllers\ajax.php 289
ERROR - 2015-02-03 19:47:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 289
ERROR - 2015-02-03 19:47:26 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 370
ERROR - 2015-02-03 19:48:03 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 370
ERROR - 2015-02-03 19:58:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE user_id = '36'' at line 1
ERROR - 2015-02-03 19:58:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE user_id = '36'' at line 1
ERROR - 2015-02-03 19:58:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE user_id = '36'' at line 1
