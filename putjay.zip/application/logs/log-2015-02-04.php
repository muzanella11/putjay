<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-04 01:29:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 287
ERROR - 2015-02-04 01:29:59 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-04 01:30:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 287
ERROR - 2015-02-04 01:30:43 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-04 01:39:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 287
ERROR - 2015-02-04 01:39:31 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-04 01:39:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 287
ERROR - 2015-02-04 01:39:39 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-04 01:46:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 287
ERROR - 2015-02-04 01:46:45 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-04 01:51:40 --> Severity: Notice  --> Undefined variable: dataJson C:\xampp\htdocs\twingernew\application\controllers\ajax.php 323
ERROR - 2015-02-04 01:56:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 287
ERROR - 2015-02-04 01:56:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-04 01:58:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 287
ERROR - 2015-02-04 01:58:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-04 02:27:41 --> Severity: Warning  --> Missing argument 1 for CI_URI::segment(), called in C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php on line 96 and defined C:\xampp\htdocs\twingernew\system\core\URI.php 341
ERROR - 2015-02-04 02:27:41 --> Severity: Notice  --> Undefined variable: n C:\xampp\htdocs\twingernew\system\core\URI.php 343
ERROR - 2015-02-04 12:51:30 --> 404 Page Not Found --> profile/lagicoba
ERROR - 2015-02-04 12:54:17 --> 404 Page Not Found --> profile/lagicoba
ERROR - 2015-02-04 13:03:48 --> Severity: Notice  --> Undefined variable: thisuser C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 98
ERROR - 2015-02-04 16:22:35 --> Severity: Notice  --> Undefined variable: thisuser C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 71
ERROR - 2015-02-04 16:22:36 --> Severity: Notice  --> Undefined variable: thisuser C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 117
ERROR - 2015-02-04 16:51:11 --> Severity: Notice  --> Undefined variable: userdata C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:51:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:52:01 --> Severity: Notice  --> Undefined variable: userdata C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:52:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:53:14 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:53:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:53:44 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:53:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:54:03 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:54:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:54:52 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:54:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:54:53 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:54:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:55:48 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:55:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:59:44 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 16:59:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:00:00 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:00:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:16 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:19 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:19 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:20 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:36 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:47 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:01:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:03:09 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:03:18 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:07:50 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:07:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:08:13 --> Severity: Notice  --> Undefined variable: a C:\xampp\htdocs\twingernew\application\controllers\profile.php 34
ERROR - 2015-02-04 17:08:13 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:08:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:08:13 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\twingernew\system\core\Loader.php 863
ERROR - 2015-02-04 17:08:57 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:08:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:09:41 --> Severity: Notice  --> Undefined variable: a C:\xampp\htdocs\twingernew\application\controllers\profile.php 34
ERROR - 2015-02-04 17:09:41 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:09:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:09:41 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\twingernew\system\core\Loader.php 863
ERROR - 2015-02-04 17:10:49 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:10:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:11:37 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:11:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:12:39 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:12:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:13:54 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:13:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:16:04 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:16:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:16:10 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:16:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:19:53 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:19:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:19:53 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 28
ERROR - 2015-02-04 17:19:53 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:19:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:20:08 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:20:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:20:08 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 28
ERROR - 2015-02-04 17:20:09 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:20:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:20:31 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:20:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:20:31 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 28
ERROR - 2015-02-04 17:20:31 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:20:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:20:40 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:20:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:22:18 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:22:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:23:59 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:24:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:25:15 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:25:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:26:42 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:26:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:26:50 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:26:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:27:04 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:27:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:27:18 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:27:18 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 28
ERROR - 2015-02-04 17:27:18 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:27:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:27:26 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:27:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:27:26 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 28
ERROR - 2015-02-04 17:27:26 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:27:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:29:07 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:29:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:29:07 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 28
ERROR - 2015-02-04 17:29:07 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:29:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:29:15 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:29:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:29:15 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 28
ERROR - 2015-02-04 17:29:15 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:29:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:29:33 --> Severity: Notice  --> Undefined variable: user_data C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:29:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:29:33 --> Severity: Notice  --> Undefined variable: image_default C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 28
ERROR - 2015-02-04 17:29:33 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:29:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:30:05 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:30:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:30:16 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:32:32 --> Severity: Notice  --> Undefined variable: b C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:32:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:35:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 33
ERROR - 2015-02-04 17:35:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 33
ERROR - 2015-02-04 17:35:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 33
ERROR - 2015-02-04 17:35:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 25
ERROR - 2015-02-04 17:35:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 119
ERROR - 2015-02-04 17:35:45 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\twingernew\system\core\Loader.php 863
