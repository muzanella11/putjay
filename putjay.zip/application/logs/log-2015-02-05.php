<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-05 18:21:07 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\controllers\logout.php 33
ERROR - 2015-02-05 18:21:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-05 18:21:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-05 18:21:24 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 30
ERROR - 2015-02-05 18:21:37 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\controllers\logout.php 33
ERROR - 2015-02-05 18:21:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-05 18:21:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-05 18:21:40 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 30
ERROR - 2015-02-05 18:21:57 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 30
ERROR - 2015-02-05 18:22:51 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 30
ERROR - 2015-02-05 18:23:41 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\controllers\logout.php 33
ERROR - 2015-02-05 18:23:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-05 18:23:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-05 19:06:32 --> 404 Page Not Found --> profile/i
