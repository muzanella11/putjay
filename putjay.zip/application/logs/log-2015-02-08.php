<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-08 13:11:17 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-02-08 17:38:46 --> Severity: Notice  --> Undefined property: Ajax::$usermodel C:\xampp\htdocs\twingernew\application\controllers\ajax.php 424
ERROR - 2015-02-08 17:41:02 --> Severity: Notice  --> Undefined property: Ajax::$usermodel C:\xampp\htdocs\twingernew\application\controllers\ajax.php 424
