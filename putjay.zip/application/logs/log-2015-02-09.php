<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-09 01:09:44 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:44 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:44 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:45 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:45 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:45 --> Severity: Notice  --> Undefined variable: datauser C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:09:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 36
ERROR - 2015-02-09 01:12:15 --> Severity: Notice  --> Undefined variable: datausername C:\xampp\htdocs\twingernew\application\controllers\profile.php 43
ERROR - 2015-02-09 01:12:15 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-09 01:25:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 38
ERROR - 2015-02-09 01:25:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-09 01:26:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 38
ERROR - 2015-02-09 01:26:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\helpers\url_helper.php 542
ERROR - 2015-02-09 01:39:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 01:40:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 01:40:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 01:41:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 01:44:27 --> Severity: Notice  --> Undefined variable: query C:\xampp\htdocs\twingernew\application\models\friend_model.php 19
ERROR - 2015-02-09 01:45:01 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 01:45:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 12:01:54 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\controllers\ajax.php 317
ERROR - 2015-02-09 12:01:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-09 12:02:05 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\controllers\ajax.php 317
ERROR - 2015-02-09 12:02:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-09 12:22:53 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\controllers\ajax.php 317
ERROR - 2015-02-09 12:22:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-09 12:23:01 --> Severity: Notice  --> Undefined property: stdClass::$status C:\xampp\htdocs\twingernew\application\controllers\ajax.php 317
ERROR - 2015-02-09 12:23:01 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\libraries\Session.php 688
ERROR - 2015-02-09 16:07:56 --> Severity: Notice  --> Undefined variable: check_friends_status C:\xampp\htdocs\twingernew\application\controllers\profile.php 68
ERROR - 2015-02-09 16:08:50 --> Severity: Notice  --> Undefined variable: check_friends_status_y C:\xampp\htdocs\twingernew\application\controllers\profile.php 71
ERROR - 2015-02-09 16:08:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 16:08:50 --> Severity: Notice  --> ob_end_clean() [<a href='ref.outcontrol'>ref.outcontrol</a>]: failed to delete buffer. No buffer to delete. C:\xampp\htdocs\twingernew\system\core\Loader.php 863
ERROR - 2015-02-09 16:09:40 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 16:09:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 16:10:34 --> Severity: Notice  --> Undefined variable: friend_status_y C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 16:10:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 16:11:43 --> Severity: Notice  --> Undefined variable: friend_status_y C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 16:11:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 16:11:43 --> Severity: Notice  --> Undefined variable: friend_status_y C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 150
ERROR - 2015-02-09 16:11:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 150
ERROR - 2015-02-09 16:11:45 --> Severity: Notice  --> Undefined variable: friend_status_y C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 16:11:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 148
ERROR - 2015-02-09 16:11:45 --> Severity: Notice  --> Undefined variable: friend_status_y C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 150
ERROR - 2015-02-09 16:11:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 150
ERROR - 2015-02-09 16:34:44 --> Severity: Notice  --> Undefined variable: friend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 155
ERROR - 2015-02-09 17:21:33 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\controllers\ajax.php 433
ERROR - 2015-02-09 17:21:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 433
ERROR - 2015-02-09 17:23:45 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\controllers\ajax.php 436
ERROR - 2015-02-09 17:23:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 436
ERROR - 2015-02-09 17:28:22 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\controllers\ajax.php 436
ERROR - 2015-02-09 17:28:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\ajax.php 436
ERROR - 2015-02-09 17:30:39 --> Severity: Notice  --> Undefined offset:  3 C:\xampp\htdocs\twingernew\application\controllers\ajax.php 434
ERROR - 2015-02-09 17:37:40 --> Severity: Notice  --> Undefined variable: friend_status C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 17:37:40 --> Severity: Notice  --> Undefined variable: friend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 149
ERROR - 2015-02-09 17:59:12 --> Severity: Notice  --> Undefined variable: friend_status_y C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 17:59:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 17:59:12 --> Severity: Notice  --> Undefined variable: friend_status_y C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-09 17:59:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-09 17:59:12 --> Severity: Notice  --> Undefined variable: friend_status_y C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-09 18:18:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 168
ERROR - 2015-02-09 23:34:13 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:34:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:34:13 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-09 23:34:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-09 23:34:13 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 171
ERROR - 2015-02-09 23:34:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 171
ERROR - 2015-02-09 23:34:58 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:34:58 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 171
ERROR - 2015-02-09 23:34:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 171
ERROR - 2015-02-09 23:38:43 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:38:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:38:43 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 171
ERROR - 2015-02-09 23:38:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 171
ERROR - 2015-02-09 23:40:06 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:40:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:40:06 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-09 23:40:06 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-09 23:40:38 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:40:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 11
ERROR - 2015-02-09 23:40:57 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-09 23:40:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-09 23:46:31 --> Severity: Notice  --> Undefined variable: friend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 168
ERROR - 2015-02-09 23:46:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 168
ERROR - 2015-02-09 23:47:27 --> Severity: Notice  --> Undefined variable: friend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 168
