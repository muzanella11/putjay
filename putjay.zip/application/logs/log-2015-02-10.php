<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-10 00:02:35 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:02:35 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:03:17 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:03:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:03:18 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:03:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:04:00 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:04:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:05:04 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 14
ERROR - 2015-02-10 00:05:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 14
ERROR - 2015-02-10 00:05:04 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:05:04 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:05:43 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:05:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:06:07 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:06:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 19
ERROR - 2015-02-10 00:08:20 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 00:15:58 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 00:15:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 00:23:29 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 00:23:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 00:23:29 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-10 00:23:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-10 00:23:29 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 164
ERROR - 2015-02-10 00:23:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 164
ERROR - 2015-02-10 00:27:07 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-10 00:27:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-10 00:27:07 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 164
ERROR - 2015-02-10 00:27:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 164
ERROR - 2015-02-10 22:35:24 --> Query error: Table 'twinger.friends' doesn't exist
ERROR - 2015-02-10 22:36:05 --> Severity: Notice  --> Undefined variable: friend_status_y C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 13
ERROR - 2015-02-10 23:04:09 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 152
ERROR - 2015-02-10 23:04:25 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 152
ERROR - 2015-02-10 23:04:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 152
ERROR - 2015-02-10 23:20:39 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-10 23:20:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-10 23:21:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-10 23:21:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 129
ERROR - 2015-02-10 23:21:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-10 23:22:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 149
ERROR - 2015-02-10 23:22:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-10 23:23:10 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-10 23:24:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-10 23:36:27 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 152
ERROR - 2015-02-10 23:36:27 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-10 23:38:26 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 23:38:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 23:38:41 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 23:38:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 23:38:42 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
ERROR - 2015-02-10 23:38:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\button\button_follow.php 12
