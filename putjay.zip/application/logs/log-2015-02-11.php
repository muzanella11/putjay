<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-11 00:28:53 --> Query error: Unknown column 'friends_user_id' in 'where clause'
ERROR - 2015-02-11 00:29:48 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 152
ERROR - 2015-02-11 00:29:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 152
ERROR - 2015-02-11 00:31:53 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 155
ERROR - 2015-02-11 00:31:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 155
ERROR - 2015-02-11 00:46:19 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:46:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:47:15 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:47:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:47:16 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:47:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:48:09 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:48:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:48:09 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 155
ERROR - 2015-02-11 00:48:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 155
ERROR - 2015-02-11 00:49:48 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:49:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 00:50:18 --> Severity: Notice  --> Undefined variable: status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 152
ERROR - 2015-02-11 00:50:18 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 154
ERROR - 2015-02-11 00:50:18 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 154
ERROR - 2015-02-11 00:57:27 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-11 00:57:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-11 01:04:00 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-11 01:04:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-11 01:04:42 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 152
ERROR - 2015-02-11 01:04:42 --> Severity: Notice  --> Undefined variable: hefriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 154
ERROR - 2015-02-11 01:04:42 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 157
ERROR - 2015-02-11 01:04:42 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 169
ERROR - 2015-02-11 01:07:10 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 160
ERROR - 2015-02-11 01:07:10 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 172
ERROR - 2015-02-11 01:07:49 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 160
ERROR - 2015-02-11 01:07:49 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 172
ERROR - 2015-02-11 01:07:51 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 160
ERROR - 2015-02-11 01:07:51 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 172
ERROR - 2015-02-11 01:08:06 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 153
ERROR - 2015-02-11 01:08:06 --> Severity: Notice  --> Undefined variable: hefriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 155
ERROR - 2015-02-11 01:08:06 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 160
ERROR - 2015-02-11 01:08:06 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 172
ERROR - 2015-02-11 01:09:29 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 160
ERROR - 2015-02-11 01:09:29 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 172
ERROR - 2015-02-11 01:09:54 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 160
ERROR - 2015-02-11 01:13:22 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 156
ERROR - 2015-02-11 01:13:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 156
ERROR - 2015-02-11 01:18:00 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 156
ERROR - 2015-02-11 01:18:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 156
ERROR - 2015-02-11 01:36:03 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 154
ERROR - 2015-02-11 01:36:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 154
ERROR - 2015-02-11 01:36:03 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 01:36:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 01:36:28 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 01:36:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 01:36:51 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 01:36:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 01:42:07 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 156
ERROR - 2015-02-11 01:42:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 156
ERROR - 2015-02-11 01:44:14 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 168
ERROR - 2015-02-11 01:44:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 168
ERROR - 2015-02-11 01:51:13 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 156
ERROR - 2015-02-11 01:51:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 156
ERROR - 2015-02-11 01:54:07 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-11 01:54:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-11 01:54:07 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-11 01:54:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 158
ERROR - 2015-02-11 17:43:54 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-11 17:44:13 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 17:44:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 17:45:23 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 17:45:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 17:59:45 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 17:59:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:02:17 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:02:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:02:33 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:02:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:02:53 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:02:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:03:44 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:03:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:04:51 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:04:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-11 18:11:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 165
ERROR - 2015-02-11 18:14:37 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 165
ERROR - 2015-02-11 18:14:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 165
ERROR - 2015-02-11 18:22:14 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
