<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-15 00:14:50 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 00:14:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 00:37:57 --> Severity: Warning  --> mysql_num_rows(): supplied argument is not a valid MySQL result resource C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 179
ERROR - 2015-02-15 00:39:42 --> Severity: Warning  --> mysql_num_rows(): supplied argument is not a valid MySQL result resource C:\xampp\htdocs\twingernew\application\controllers\profile.php 67
ERROR - 2015-02-15 00:42:29 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 00:46:27 --> Severity: Warning  --> mysql_num_rows(): supplied argument is not a valid MySQL result resource C:\xampp\htdocs\twingernew\application\controllers\profile.php 67
ERROR - 2015-02-15 00:47:10 --> Severity: Warning  --> mysql_num_rows(): supplied argument is not a valid MySQL result resource C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 179
ERROR - 2015-02-15 00:51:12 --> Severity: Warning  --> mysql_num_rows(): supplied argument is not a valid MySQL result resource C:\xampp\htdocs\twingernew\application\controllers\profile.php 67
ERROR - 2015-02-15 00:51:31 --> Severity: Warning  --> mysql_num_rows(): supplied argument is not a valid MySQL result resource C:\xampp\htdocs\twingernew\application\controllers\profile.php 67
ERROR - 2015-02-15 00:56:55 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 180
ERROR - 2015-02-15 00:57:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 180
ERROR - 2015-02-15 01:00:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 67
ERROR - 2015-02-15 01:12:32 --> Severity: Notice  --> Undefined variable: get_following C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 65
ERROR - 2015-02-15 01:18:45 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:18:48 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:19:26 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:23:52 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:23:53 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:30:19 --> Query error: Table 'twinger.friend' doesn't exist
ERROR - 2015-02-15 01:31:54 --> Query error: Table 'twinger.friend' doesn't exist
ERROR - 2015-02-15 01:32:56 --> Query error: Table 'twinger.friend' doesn't exist
ERROR - 2015-02-15 01:42:56 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 01:42:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 01:43:22 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:46:31 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:47:58 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:47:59 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:50:01 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:52:06 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:52:29 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:56:02 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:56:03 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:56:37 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:56:49 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 01:56:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 01:59:20 --> 404 Page Not Found --> s123
ERROR - 2015-02-15 01:59:34 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 01:59:48 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 01:59:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:00:00 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:01:46 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:01:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:05:47 --> 404 Page Not Found --> id
ERROR - 2015-02-15 02:07:01 --> 404 Page Not Found --> id
ERROR - 2015-02-15 02:07:25 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:07:43 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:08:16 --> 404 Page Not Found --> profile/asasas
ERROR - 2015-02-15 02:09:24 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:09:30 --> 404 Page Not Found --> profile/asds
ERROR - 2015-02-15 02:09:49 --> 404 Page Not Found --> profile/asds
ERROR - 2015-02-15 02:09:52 --> 404 Page Not Found --> profile/asds
ERROR - 2015-02-15 02:10:15 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:10:24 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:10:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:13:04 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:13:42 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:13:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:15:22 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:22:02 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:22:13 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:25:25 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:25:44 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-15 02:29:49 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:29:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:30:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\profile.php 42
ERROR - 2015-02-15 02:30:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and friends_target_id=1' at line 1
ERROR - 2015-02-15 02:30:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\core\Common.php 442
ERROR - 2015-02-15 02:38:03 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 02:38:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-15 21:45:30 --> Query error: Unknown column 'status' in 'field list'
ERROR - 2015-02-15 21:45:46 --> Query error: Unknown column 'status' in 'field list'
ERROR - 2015-02-15 21:47:21 --> Query error: Unknown column 'status' in 'field list'
