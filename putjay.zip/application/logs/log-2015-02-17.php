<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-17 07:10:09 --> Query error: Unknown column 'status' in 'field list'
ERROR - 2015-02-17 07:22:26 --> Query error: Unknown column 'status' in 'field list'
ERROR - 2015-02-17 08:05:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\home.php 58
ERROR - 2015-02-17 08:05:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
ERROR - 2015-02-17 08:05:21 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\twingernew\system\core\Exceptions.php:185) C:\xampp\htdocs\twingernew\system\core\Common.php 442
ERROR - 2015-02-17 08:06:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\controllers\home.php 53
ERROR - 2015-02-17 08:13:21 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:15:36 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:17:49 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:18:02 --> 404 Page Not Found --> i
ERROR - 2015-02-17 08:18:28 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:34:59 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:35:23 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:35:24 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:41:19 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:41:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:42:21 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:43:03 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:43:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:43:23 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:43:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:45:01 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:45:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:45:12 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:45:42 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:46:01 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:46:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:46:32 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:46:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:46:40 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:46:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:48:45 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:51:15 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-17 08:51:34 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:51:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:53:16 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:53:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:55:55 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:55:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:56:05 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:56:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:56:23 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:56:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:57:03 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:57:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:57:27 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:57:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:58:22 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:58:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:59:37 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:59:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:59:42 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:59:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:59:54 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 08:59:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 09:00:05 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 09:00:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 09:00:45 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-17 09:00:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
