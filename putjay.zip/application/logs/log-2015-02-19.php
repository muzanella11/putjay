<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-19 13:49:41 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-02-19 14:36:41 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-02-19 14:36:51 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-19 14:36:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-19 14:36:55 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
ERROR - 2015-02-19 14:36:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 167
