<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-22 13:44:08 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 110
ERROR - 2015-02-22 13:46:30 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 110
ERROR - 2015-02-22 13:48:02 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 110
ERROR - 2015-02-22 13:48:18 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 110
ERROR - 2015-02-22 13:48:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 112
ERROR - 2015-02-22 13:49:32 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 110
ERROR - 2015-02-22 13:49:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 112
ERROR - 2015-02-22 13:49:33 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 110
ERROR - 2015-02-22 13:49:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 112
ERROR - 2015-02-22 13:49:51 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 110
ERROR - 2015-02-22 13:52:35 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 110
ERROR - 2015-02-22 13:53:29 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 107
ERROR - 2015-02-22 13:56:10 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 111
ERROR - 2015-02-22 13:56:30 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 111
ERROR - 2015-02-22 13:56:30 --> Severity: Warning  --> explode() [<a href='function.explode'>function.explode</a>]: Empty delimiter C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 111
ERROR - 2015-02-22 13:56:42 --> Severity: Warning  --> Wrong parameter count for explode() C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 111
ERROR - 2015-02-22 13:57:30 --> Severity: Notice  --> Undefined offset:  4 C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 112
ERROR - 2015-02-22 13:57:40 --> Severity: Notice  --> Undefined offset:  3 C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 112
ERROR - 2015-02-22 13:57:46 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 112
ERROR - 2015-02-22 13:58:07 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 112
ERROR - 2015-02-22 13:58:17 --> Severity: Notice  --> Undefined offset:  0 C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 112
ERROR - 2015-02-22 13:58:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 112
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:03:29 --> Severity: 4096  --> Object of class stdClass could not be converted to string C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:04:09 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 102
ERROR - 2015-02-22 14:08:24 --> Severity: Notice  --> Undefined property: stdClass::$username C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 101
ERROR - 2015-02-22 14:08:33 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 101
ERROR - 2015-02-22 14:09:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 101
ERROR - 2015-02-22 14:10:11 --> Severity: Notice  --> Undefined property: stdClass::$friends_id_target C:\xampp\htdocs\twingernew\application\views\templates\twinger.php 101
ERROR - 2015-02-22 14:17:04 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
