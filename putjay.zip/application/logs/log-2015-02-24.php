<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-24 22:37:20 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
