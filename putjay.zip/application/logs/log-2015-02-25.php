<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-02-25 00:09:13 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-02-25 10:06:49 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-02-25 13:25:54 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-02-25 13:26:07 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-02-25 16:11:16 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-02-25 16:15:09 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
