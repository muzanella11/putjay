<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-01 14:49:57 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-01 18:45:48 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-01 18:49:08 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-01 19:33:38 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-01 19:36:49 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-01 21:55:01 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-01 22:01:55 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
