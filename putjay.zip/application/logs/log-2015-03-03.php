<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-03 17:06:00 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-03 17:06:39 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
