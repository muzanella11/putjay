<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-06 12:50:10 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-06 12:52:23 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-06 12:55:01 --> 404 Page Not Found --> i
ERROR - 2015-03-06 13:00:09 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-03-06 13:03:30 --> 404 Page Not Found --> i
ERROR - 2015-03-06 13:03:46 --> 404 Page Not Found --> discover
ERROR - 2015-03-06 13:03:50 --> 404 Page Not Found --> message
ERROR - 2015-03-06 13:12:20 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-06 13:12:20 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-06 13:12:20 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
