<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-10 14:52:29 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-10 16:39:21 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
