<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-03-18 21:05:11 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-18 21:06:05 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-03-18 21:12:52 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-18 21:13:07 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-03-18 21:20:36 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-18 21:20:55 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
ERROR - 2015-03-18 21:31:22 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-03-18 21:31:30 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
