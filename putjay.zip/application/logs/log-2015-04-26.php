<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-26 17:30:30 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-04-26 17:36:17 --> Severity: Notice  --> Undefined variable: myfriend_status C:\xampp\htdocs\twingernew\application\views\templates\profile\profile_body.php 166
