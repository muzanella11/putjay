<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-04-28 04:32:19 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\wimobo\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-28 04:32:35 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\wimobo\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-28 04:32:38 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\wimobo\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-28 04:39:24 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\wimobo\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-28 04:41:28 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:41:34 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:41:35 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:41:36 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:41:37 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:41:38 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:41:53 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:42:28 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:42:29 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:42:29 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:42:34 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:43:29 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:43:31 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-04-28 04:43:41 --> 404 Page Not Found --> sign_inl
ERROR - 2015-04-28 04:43:46 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:43:51 --> 404 Page Not Found --> home
ERROR - 2015-04-28 04:49:21 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\wimobo\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-04-28 04:50:36 --> 404 Page Not Found --> hoome
ERROR - 2015-04-28 06:46:40 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\wimobo\system\database\drivers\mysql\mysql_driver.php 91
