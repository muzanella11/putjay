<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-01 09:32:28 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-01 09:33:31 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-01 09:34:23 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-01 09:37:22 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-01 10:33:14 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-01 15:32:19 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
ERROR - 2015-05-01 15:54:37 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
