<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-02 03:21:34 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-02 03:22:32 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-02 03:23:11 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-02 03:35:17 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-02 03:40:27 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-02 03:47:21 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\sosmed\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-02 06:06:49 --> Query error: Table 'sosmed.engine4_user' doesn't exist
ERROR - 2015-05-02 07:26:31 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:31 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:31 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:31 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:31 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:32 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:32 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:32 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:33 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:39 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:40 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:40 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:40 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
ERROR - 2015-05-02 07:26:41 --> Severity: Warning  --> preg_match() [<a href='function.preg-match'>function.preg-match</a>]: Delimiter must not be alphanumeric or backslash C:\xampp\htdocs\sosmed\application\controllers\ajax.php 121
