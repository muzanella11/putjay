<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-08 10:32:14 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
