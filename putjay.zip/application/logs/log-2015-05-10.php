<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-10 16:34:16 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-10 16:34:23 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-10 16:34:23 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:38:07 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:38:59 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:44:13 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-10 16:44:13 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:44:16 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:45:02 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:46:50 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-10 16:46:50 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:46:55 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:47:03 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:47:11 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:47:16 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-10 16:47:17 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:54:20 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-10 16:54:21 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 16:55:43 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:07:33 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:10:50 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:10:53 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:13:21 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:15:11 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:15:50 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:16:05 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:16:20 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:16:31 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:20:30 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:20:32 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:21:19 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:21:20 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:21:33 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:21:35 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:21:36 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:21:37 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:22:59 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-10 17:45:27 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
