<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-11 04:16:52 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-11 04:16:58 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-11 04:16:58 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:17:18 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:17:53 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:40:09 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-11 04:40:09 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-11 04:40:10 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-11 04:40:10 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:40:10 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:40:13 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:43:00 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:44:04 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:58:47 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:58:52 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:59:53 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 04:59:53 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 05:09:41 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-11 11:19:12 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 11:19:13 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 11:26:38 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 11:26:38 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 11:56:22 --> Severity: Notice  --> Undefined property: Ajax::$model C:\xampp\htdocs\putjay\application\controllers\ajax.php 141
ERROR - 2015-05-11 11:56:44 --> Severity: Notice  --> Undefined property: Ajax::$model C:\xampp\htdocs\putjay\application\controllers\ajax.php 141
ERROR - 2015-05-11 12:04:51 --> Severity: Notice  --> Undefined property: Ajax::$model C:\xampp\htdocs\putjay\application\controllers\ajax.php 141
ERROR - 2015-05-11 12:20:41 --> Severity: Notice  --> Undefined variable: allitems C:\xampp\htdocs\putjay\application\views\templates\admin\report\report_user_body.php 4
ERROR - 2015-05-11 12:26:45 --> Severity: Notice  --> Undefined variable: allitems C:\xampp\htdocs\putjay\application\views\templates\admin\report\report_user_body.php 4
ERROR - 2015-05-11 12:26:48 --> Severity: Notice  --> Undefined variable: allitems C:\xampp\htdocs\putjay\application\views\templates\admin\report\report_user_body.php 4
ERROR - 2015-05-11 12:26:49 --> Severity: Notice  --> Undefined variable: allitems C:\xampp\htdocs\putjay\application\views\templates\admin\report\report_user_body.php 4
ERROR - 2015-05-11 12:26:50 --> Severity: Notice  --> Undefined variable: allitems C:\xampp\htdocs\putjay\application\views\templates\admin\report\report_user_body.php 4
ERROR - 2015-05-11 12:26:51 --> Severity: Notice  --> Undefined variable: allitems C:\xampp\htdocs\putjay\application\views\templates\admin\report\report_user_body.php 4
ERROR - 2015-05-11 12:34:07 --> Severity: Notice  --> Undefined variable: allpromo C:\xampp\htdocs\putjay\application\views\templates\admin\report\report_promo_body.php 4
ERROR - 2015-05-11 12:41:45 --> Severity: Notice  --> Undefined variable: alluser C:\xampp\htdocs\putjay\application\views\templates\admin\admin_body.php 65
ERROR - 2015-05-11 13:10:53 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 15:24:01 --> Severity: Notice  --> Undefined variable: allpromo C:\xampp\htdocs\putjay\application\views\templates\admin\report\report_promo_body.php 4
ERROR - 2015-05-11 16:04:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%s%'' at line 1
ERROR - 2015-05-11 16:04:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%st%'' at line 1
ERROR - 2015-05-11 16:04:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stu%'' at line 1
ERROR - 2015-05-11 16:04:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stup%'' at line 1
ERROR - 2015-05-11 16:04:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stupi%'' at line 1
ERROR - 2015-05-11 16:04:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stupid%'' at line 1
ERROR - 2015-05-11 16:04:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stupid %'' at line 1
ERROR - 2015-05-11 16:04:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stupid p%'' at line 1
ERROR - 2015-05-11 16:04:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stupid ph%'' at line 1
ERROR - 2015-05-11 16:04:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stupid pho%'' at line 1
ERROR - 2015-05-11 16:04:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stupid phon%'' at line 1
ERROR - 2015-05-11 16:04:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE nama='%stupid phone%'' at line 1
ERROR - 2015-05-11 18:20:03 --> Query error: Unknown column 'promo' in 'field list'
ERROR - 2015-05-11 18:21:42 --> Severity: Notice  --> Undefined variable: allpromo C:\xampp\htdocs\putjay\application\views\templates\admin\report\report_promo_body.php 4
ERROR - 2015-05-11 18:36:35 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 18:38:34 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 18:38:46 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-11 18:40:17 --> Severity: Notice  --> Undefined variable: items_id C:\xampp\htdocs\putjay\application\core\MY_Model.php 54
ERROR - 2015-05-11 18:51:48 --> Severity: Notice  --> Undefined variable: no_avatar C:\xampp\htdocs\putjay\application\views\templates\putjay.php 62
ERROR - 2015-05-11 18:52:13 --> Severity: Notice  --> Undefined property: Templates::$no_avatar C:\xampp\htdocs\putjay\application\controllers\home.php 39
ERROR - 2015-05-11 18:52:13 --> Severity: Notice  --> Undefined variable: no_avatar C:\xampp\htdocs\putjay\application\views\templates\putjay.php 62
