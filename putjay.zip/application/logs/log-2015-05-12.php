<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-12 04:03:39 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-12 04:12:53 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-12 04:13:37 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-12 04:56:25 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 04:56:26 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 04:56:27 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 04:57:11 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 04:57:12 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 04:57:12 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 05:25:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\putjay\application\views\templates\promo\promo_detil_body.php 57
ERROR - 2015-05-12 05:40:15 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-12 06:22:06 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-12 06:22:09 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 06:22:10 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 06:22:11 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 06:41:39 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 06:57:57 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-12 07:01:14 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\putjay\application\views\templates\category\all_category_body.php 15
ERROR - 2015-05-12 07:06:39 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\putjay\application\views\templates\category\all_category_body.php 15
ERROR - 2015-05-12 07:07:01 --> Severity: Notice  --> Undefined variable: kategori C:\xampp\htdocs\putjay\application\views\templates\category\all_category_body.php 15
ERROR - 2015-05-12 07:12:13 --> Severity: Notice  --> Undefined variable: no_image C:\xampp\htdocs\putjay\application\views\templates\category\all_category_body.php 22
ERROR - 2015-05-12 07:22:43 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 07:22:44 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 08:06:38 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 08:06:39 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 08:08:45 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 08:08:45 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 08:11:04 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 08:11:04 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 08:11:04 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 12:45:30 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 12:45:31 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 14:02:26 --> Severity: Notice  --> Undefined variable: data_username C:\xampp\htdocs\putjay\application\controllers\ajax.php 144
ERROR - 2015-05-12 14:02:26 --> Severity: Notice  --> Undefined variable: user_id C:\xampp\htdocs\putjay\application\controllers\ajax.php 155
ERROR - 2015-05-12 14:02:26 --> Severity: Notice  --> Undefined index: first_name C:\xampp\htdocs\putjay\application\core\MY_Model.php 151
ERROR - 2015-05-12 14:02:26 --> Severity: Notice  --> Undefined index: last_name C:\xampp\htdocs\putjay\application\core\MY_Model.php 152
ERROR - 2015-05-12 14:02:26 --> Query error: Unknown column 'user_id' in 'where clause'
ERROR - 2015-05-12 14:04:13 --> Severity: Notice  --> Undefined variable: data_username C:\xampp\htdocs\putjay\application\controllers\ajax.php 144
ERROR - 2015-05-12 14:05:23 --> Severity: Notice  --> Undefined variable: data_username C:\xampp\htdocs\putjay\application\controllers\ajax.php 144
ERROR - 2015-05-12 14:09:36 --> Severity: Warning  --> Missing argument 1 for MY_Model::getDataUserByUsername(), called in C:\xampp\htdocs\putjay\application\controllers\ajax.php on line 48 and defined C:\xampp\htdocs\putjay\application\core\MY_Model.php 149
ERROR - 2015-05-12 14:09:36 --> Severity: Notice  --> Undefined variable: username C:\xampp\htdocs\putjay\application\core\MY_Model.php 150
ERROR - 2015-05-12 14:09:36 --> Severity: Notice  --> Undefined variable: data_username C:\xampp\htdocs\putjay\application\controllers\ajax.php 145
ERROR - 2015-05-12 14:09:36 --> Severity: Warning  --> Missing argument 1 for MY_Model::getDataUserByUsername(), called in C:\xampp\htdocs\putjay\application\controllers\ajax.php on line 48 and defined C:\xampp\htdocs\putjay\application\core\MY_Model.php 149
ERROR - 2015-05-12 14:09:36 --> Severity: Notice  --> Undefined variable: username C:\xampp\htdocs\putjay\application\core\MY_Model.php 150
ERROR - 2015-05-12 14:12:15 --> Severity: Warning  --> Missing argument 1 for MY_Model::getDataUserByUsername(), called in C:\xampp\htdocs\putjay\application\controllers\ajax.php on line 48 and defined C:\xampp\htdocs\putjay\application\core\MY_Model.php 149
ERROR - 2015-05-12 14:12:15 --> Severity: Notice  --> Undefined variable: username C:\xampp\htdocs\putjay\application\core\MY_Model.php 150
ERROR - 2015-05-12 14:14:01 --> Severity: Warning  --> Missing argument 1 for MY_Model::getDataUserByUsername(), called in C:\xampp\htdocs\putjay\application\controllers\ajax.php on line 48 and defined C:\xampp\htdocs\putjay\application\core\MY_Model.php 149
ERROR - 2015-05-12 14:14:01 --> Severity: Notice  --> Undefined variable: username C:\xampp\htdocs\putjay\application\core\MY_Model.php 150
ERROR - 2015-05-12 14:14:01 --> Severity: Warning  --> Missing argument 1 for MY_Model::getDataUserByUsername(), called in C:\xampp\htdocs\putjay\application\controllers\ajax.php on line 48 and defined C:\xampp\htdocs\putjay\application\core\MY_Model.php 149
ERROR - 2015-05-12 14:14:01 --> Severity: Notice  --> Undefined variable: username C:\xampp\htdocs\putjay\application\core\MY_Model.php 150
ERROR - 2015-05-12 14:14:12 --> Severity: Warning  --> Missing argument 1 for MY_Model::getDataUserByUsername(), called in C:\xampp\htdocs\putjay\application\controllers\ajax.php on line 48 and defined C:\xampp\htdocs\putjay\application\core\MY_Model.php 149
ERROR - 2015-05-12 14:14:12 --> Severity: Notice  --> Undefined variable: username C:\xampp\htdocs\putjay\application\core\MY_Model.php 150
ERROR - 2015-05-12 14:14:12 --> Severity: Warning  --> Missing argument 1 for MY_Model::getDataUserByUsername(), called in C:\xampp\htdocs\putjay\application\controllers\ajax.php on line 48 and defined C:\xampp\htdocs\putjay\application\core\MY_Model.php 149
ERROR - 2015-05-12 14:14:12 --> Severity: Notice  --> Undefined variable: username C:\xampp\htdocs\putjay\application\core\MY_Model.php 150
ERROR - 2015-05-12 16:30:33 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\ajax.php 94
ERROR - 2015-05-12 16:30:33 --> Query error: Unknown column 'user_id' in 'where clause'
ERROR - 2015-05-12 16:30:40 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\ajax.php 94
ERROR - 2015-05-12 16:30:40 --> Query error: Unknown column 'user_id' in 'where clause'
ERROR - 2015-05-12 16:33:57 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\ajax.php 94
ERROR - 2015-05-12 16:33:58 --> Query error: Unknown column 'user_id' in 'where clause'
ERROR - 2015-05-12 16:39:11 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\logout.php 24
ERROR - 2015-05-12 16:40:04 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\logout.php 24
ERROR - 2015-05-12 17:00:10 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 17:00:10 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 17:00:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\putjay\application\views\templates\category\category_detil_body.php 10
ERROR - 2015-05-12 17:00:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\putjay\application\views\templates\category\category_detil_body.php 10
ERROR - 2015-05-12 17:00:43 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-12 17:01:18 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\logout.php 24
ERROR - 2015-05-12 17:18:11 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 17:33:33 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-12 17:45:03 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-12 17:54:33 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-12 17:56:23 --> Severity: Notice  --> Undefined variable: cart C:\xampp\htdocs\putjay\application\views\templates\cart\cart_body.php 15
ERROR - 2015-05-12 18:18:40 --> Query error: Unknown column 'id_user' in 'where clause'
ERROR - 2015-05-12 18:51:17 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\logout.php 24
