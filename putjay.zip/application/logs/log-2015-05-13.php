<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2015-05-13 03:45:15 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-13 03:45:16 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 03:45:17 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 03:45:28 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 03:45:28 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 03:48:15 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\logout.php 24
ERROR - 2015-05-13 03:52:22 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\logout.php 24
ERROR - 2015-05-13 03:55:03 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-13 03:56:58 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-13 04:36:13 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 04:39:29 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 04:39:29 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 04:40:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\putjay\application\views\templates\category\category_detil_body.php 10
ERROR - 2015-05-13 04:40:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\putjay\application\views\templates\category\category_detil_body.php 10
ERROR - 2015-05-13 04:59:13 --> Severity: Notice  --> Undefined property: stdClass::$nama C:\xampp\htdocs\putjay\application\views\templates\cart\cart_body.php 35
ERROR - 2015-05-13 05:02:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\putjay\application\views\templates\category\category_detil_body.php 10
ERROR - 2015-05-13 05:02:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\putjay\application\views\templates\category\category_detil_body.php 10
ERROR - 2015-05-13 05:03:02 --> Severity: Notice  --> Undefined property: stdClass::$nama C:\xampp\htdocs\putjay\application\views\templates\cart\cart_body.php 35
ERROR - 2015-05-13 05:03:02 --> Severity: Notice  --> Undefined property: stdClass::$nama C:\xampp\htdocs\putjay\application\views\templates\cart\cart_body.php 35
ERROR - 2015-05-13 05:10:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\putjay\application\views\templates\category\category_detil_body.php 10
ERROR - 2015-05-13 05:10:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\putjay\application\views\templates\category\category_detil_body.php 10
ERROR - 2015-05-13 05:22:33 --> Severity: Notice  --> Undefined property: stdClass::$deskripsi C:\xampp\htdocs\putjay\application\views\templates\cart\cart_body.php 39
ERROR - 2015-05-13 05:22:33 --> Severity: Notice  --> Undefined property: stdClass::$deskripsi C:\xampp\htdocs\putjay\application\views\templates\cart\cart_body.php 39
ERROR - 2015-05-13 05:22:33 --> Severity: Notice  --> Undefined property: stdClass::$deskripsi C:\xampp\htdocs\putjay\application\views\templates\cart\cart_body.php 39
ERROR - 2015-05-13 05:22:33 --> Severity: Notice  --> Undefined property: stdClass::$deskripsi C:\xampp\htdocs\putjay\application\views\templates\cart\cart_body.php 39
ERROR - 2015-05-13 05:48:24 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-13 05:48:29 --> Severity: Notice  --> Undefined property: stdClass::$user_id C:\xampp\htdocs\putjay\application\controllers\logout.php 24
ERROR - 2015-05-13 05:59:02 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:01:12 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:01:32 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:01:46 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:01:52 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:01:56 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:02:26 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:02:28 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:03:21 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:03:23 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:03:27 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:03:36 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:03:46 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:06:40 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:07:09 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:07:15 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:07:20 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:07:23 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:07:59 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\putjay\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2015-05-13 06:07:59 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:08:42 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:12:46 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:12:48 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:13:09 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:13:12 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:13:18 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:15:31 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:15:52 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:15:54 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:15:59 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:16:00 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:26:47 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:26:53 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
ERROR - 2015-05-13 06:26:57 --> Severity: Notice  --> Undefined variable: content_footer C:\xampp\htdocs\putjay\application\views\footer.php 12
