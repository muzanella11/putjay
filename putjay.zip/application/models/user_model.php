<?php

/**
 * @author f1108k
 * @copyright 2015
 * status in time line :
 * 0 = pembuat
 * 1 = pembaca
 * 2 = retwing
 */



?>
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class User_model extends MY_Model{
		function __construct(){
			parent::__construct();
		}
        
    }
?>