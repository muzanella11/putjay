<?php

/**
 * @author f1108k
 * @copyright 2015
 */



?>
<?php
	if($content_body){
		$this->load->view($content_body);	
	}
?>