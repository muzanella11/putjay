<?php

/**
 * @author f1108k
 * @copyright 2015
 */



?>
<?php
	if($content_footer){
		$this->load->view($content_footer);	
	}
?>
<div class="box_ellapsed_time" style="padding: 11px; background: skyblue; position: fixed; bottom: 0; left: 0;">
{elapsed_time}
</div>
</body>
</html>