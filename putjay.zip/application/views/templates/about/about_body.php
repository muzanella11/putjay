<div class="separator_top"></div>
<div class="container-fluid" style="background:#99FF66; height:300px;">
	<div class="col-lg-12 normal_padding box_title_page">About</div>
</div>