<h1>
	Input new Category
</h1>
<form>
<input type="text" name="nama" />
</form>